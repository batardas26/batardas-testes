# Recuperar a publicação R3.3-A.5.1

Este pacote repõe a configuração pública do ambiente TESTES e mantém as correções da pesquisa e do perfil do utilizador.

1. Descompacta o ZIP.
2. No GitHub, abre `batardas-testes/a51/assets`.
3. Elimina apenas todos os ficheiros cujo nome começa por `index-`.
4. Regressa à pasta `a51`.
5. Escolhe **Add file > Upload files**.
6. Arrasta o conteúdo de `PUBLICAR-CORRECAO-GITHUB/a51`: `index.html`, `assets` e `img`.
7. Confirma o commit com a mensagem `Repor configuração pública da A.5.1`.
8. Aguarda cerca de dois minutos.
9. Abre `https://batardas26.github.io/batardas-testes/a51/` e executa `Ctrl + F5`.

Não executar SQL, não alterar a pasta `app` e não terminar a sessão.
